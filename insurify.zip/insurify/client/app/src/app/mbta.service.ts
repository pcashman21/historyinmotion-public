/**
 * @file mbta.service.ts
 * @description Encapsulates calls to MBTA V3 API
 */

// Third Party Modules
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// Local Modules and Files
import { ScheduleBoard, ScheduleBoardRow } from 'src/app/scheduleBoard';

@Injectable({
  providedIn: 'root'
})
export class MbtaService {
  private _queryPredictionsRoot = 'https://api-v3.mbta.com/predictions?filter%5Bstop%5D=place-sstat&filter%5Bdirection_id%5D=&include=stop';
  private _querySchedulesRoot = "https://api-v3.mbta.com/schedules?fields%5Bschedule%5D=departure_time%2C%20arrival_time%2C%20status&include=prediction&filter%5Bdirection_id%5D=&filter%5Bstop%5D=place-sstat"
  private _directionQueryParameterRoot = 'direction_id%5D=';
  private _queryPredictions: string;
  private _querySchedules: string;

  constructor(
    private _httpClient: HttpClient
  ) { }

  /**
   * @method getPredictions
   * @description Call MBTA API to get predictions of departures from South Station
   * @param direction: 0 = outbound, 1 = inbound
   */
  public async getPredictions(direction: Direction): Promise<any> {
    const httpOptions = {
      headers: new HttpHeaders({})
    };
    const directionQueryParameter = `${this._directionQueryParameterRoot}=${direction}`;
    this._queryPredictions = this._queryPredictionsRoot.replace(this._directionQueryParameterRoot, directionQueryParameter);
    return this._httpClient.get<string>(this._queryPredictions, httpOptions).toPromise();
  }

  /**
   * @method getSchedules
   * @description Call MBTA API to get schedules of departures from South Station
   */
  public async getSchedules(direction: Direction): Promise<any> {
    const httpOptions = {
      headers: new HttpHeaders({})
    };
    const directionQueryParameter = `${this._directionQueryParameterRoot}=${direction}`;
    this._querySchedules = this._querySchedulesRoot.replace(this._directionQueryParameterRoot, directionQueryParameter);
    return this._httpClient.get<string>(this._querySchedules, httpOptions).toPromise();
  }

  /**
   * @method translateRawDataToScheduleBoard
   * @description Given an array of raw data (predictions or schedules), produce a ScheduleBoard instance
   */
  public translateRawDataToScheduleBoard(rawData: any, direction: Direction): ScheduleBoard {
    // First, find all commuter rail (CR) departures/arrivals
    const trips: any[] = rawData.data.filter((prediction: any) => {
      return (prediction.relationships.route.data.id.indexOf('CR-') === 0);
    });

    // Next, Find all scheduled departures/arrivals
    const scheduledTrips: any[] = trips.filter((trip: any) => {
      const isScheduled = (direction === Direction.Outbound) ? Boolean(trip.attributes.departure_time)
        : Boolean(trip.attributes.arrival_time);
      return isScheduled || (trip.attributes.status !== '');
    });

    // Now turn the scheduled trips into rows for the schedule board
    const mapToTrain = new Map();
    const rows: ScheduleBoardRow[] = scheduledTrips.map((scheduledTrip: any) => {
      const options: any = {};
      options.carrier = 'MBTA';
      const directionAttribute: string = (direction === Direction.Outbound) ? 'departure_time' : 'arrival_time';
      options.time = this.getMbtaTime(scheduledTrip.attributes[directionAttribute]);
      options.destination = this._getMbtaDestination(scheduledTrip.relationships.route.data.id);
      options.direction = direction;
      options.train = this._getMbtaTrain(scheduledTrip.relationships.trip.data.id);
      options.track = this._getMbtaTrack(scheduledTrip.relationships.stop.data.id);
      options.status = this._getMbtaStatus(scheduledTrip.attributes.status);
      const scheduleBoardRow =  new ScheduleBoardRow(options);
      // Add to a Map that maps the train # to its ScheduleBoardRow.  We'll need this
      // when we intersect schedules and predictions.
      mapToTrain.set(options.train, scheduleBoardRow);
      return scheduleBoardRow;
    });

    const board = new ScheduleBoard({
      rows,
      mapToTrain
    });
    return board;
  }

  /**
   * Helper functions to extract/map elements of the JSON reply to the formats
   * we need for display on the big board.
   */

  // Raw data is an ISO Time string
  public getMbtaTime(isoTime: string): string {
    const date = new Date(isoTime);
    let hours = date.getHours();
    const ampm = (hours < 11) ? 'AM' : 'PM';
    hours = (hours < 12) ? hours : (hours - 12);
    const minute = date.getMinutes();
    return `${(hours < 10) ? ('0' + hours) : hours}:${(minute < 10) ? ('0' + minute) : minute} ${ampm}`;
  }

  // Raw data is of the form (e.g.) 'CR-Kingston', 'CR-Providence'
  private _getMbtaDestination(dest: string): string {
    return dest.slice(3).toUpperCase();
  }

  // Raw data is of the form (e.g.) 'CR-Weekday-Summer-20-005' and
  // the train number is the last component.
  private _getMbtaTrain(trip: string): string {
    return trip.split('-').reverse()[0];
  }

  // Raw data is of the form (e.g.) 'South Station-03', or just
  // 'South Station' if no track has been assigned yet.
  private _getMbtaTrack(stop: string): string {
    if (stop.indexOf('-') > -1) {
      const track = parseInt(stop.split('-').reverse()[0], 10);
      return track.toString(); // Get rid of leading 0
    }
    return 'TBD';
  }

  private _getMbtaStatus(status: string): string {
    return status;
  }

}

export enum Direction {
  Outbound = 0,
  Inbound
}
