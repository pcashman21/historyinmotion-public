/**
 * @file app.component.ts
 * @description SPA for displaying MBTA schedule info
 */

 // Third Party Modules
import { Component, OnInit } from '@angular/core';

// Local Modules and Files

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public proceedToSchedule = false;

  constructor() { }

  ngOnInit(): void {
    this.proceedToSchedule = true;
  }

}
