/**
 * @file scheduleBoard.ts
 * @description Defines ScheduleBoard and ScheduleBoardRow classes
 */

import { Direction } from './mbta.service';

export class ScheduleBoard {
    private _rows: ScheduleBoardRow[];
    private _mapToTrain: Map<number, ScheduleBoardRow>;
    private _terminus: string;

    constructor(options: any) {
        this._rows = options.rows;
        this._mapToTrain = options.mapToTrain;
        this._terminus = 'SOUTH STATION';
    }

    get rows(): ScheduleBoardRow[] {
        return this._rows;
    }

    set rows(scheduleRows: ScheduleBoardRow[]) {
        this._rows = scheduleRows;
    }

    get mapToTrain(): Map<number, ScheduleBoardRow> {
        return this._mapToTrain;
    }

    get terminus(): string {
        return this._terminus;
    }
}

export class ScheduleBoardRow {
    private _carrier: string; // Amtrak, MBTA
    private _time: string; // arrival or departure, depedning on direction
    private _destination: string;
    private _direction: Direction;
    private _train: string;
    private _track: string;
    private _status: string;

    constructor(options: any) {
        this._carrier = options.carrier;
        this._time = options.time;
        this._destination = options.destination;
        this._direction = options.direction;
        this._train = options.train;
        this._track = options.track || 'TBD';
        this._status = options.status ? options.status.toUpperCase() : 'ON TIME';
    }

    get carrier(): string {
        return this._carrier;
    }

    get time(): string {
        return this._time;
    }

    set time(whichTime: string) {
        this._time = whichTime;
    }

    get destination(): string {
        return this._destination;
    }

    get direction(): Direction {
        return this._direction;
    }

    set direction(dir: Direction) {
        this._direction = dir;
    }

    get train(): string {
        return this._train;
    }

    get track(): string {
        return this._track;
    }

    get status(): string {
        return this._status;
    }
}
