/**
 * @file: schedule-board.component.ts
 * @description: Class to display the departures/arrivals board
 */

import { Component, OnInit } from '@angular/core';
import { MbtaService, Direction } from 'src/app/mbta.service';
import { ScheduleBoard, ScheduleBoardRow } from 'src/app/scheduleBoard';

@Component({
  selector: 'app-schedule-board',
  templateUrl: './schedule-board.component.html',
  styleUrls: ['./schedule-board.component.scss']
})
export class ScheduleBoardComponent implements OnInit {
  public hasSchedule = false;
  public dayOfWeek: string;
  public todaysDate: string;
  public timeNow: string;
  public scheduleBoardToDisplay = new ScheduleBoard({});
  private _scheduleBoardOutbound: ScheduleBoard;
  private _scheduleBoardInbound: ScheduleBoard;
  private _scheduleBoardPredictionsOutbound: ScheduleBoard;
  private _scheduleBoardSchedulesOutbound: ScheduleBoard;
  private _scheduleBoardPredictionsInbound: ScheduleBoard;
  private _scheduleBoardSchedulesInbound: ScheduleBoard;
  private _weekdays = [
    'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
  ];
  private _maxRowsToDisplay = 12;
  private _maxDepartureRowsToDisplayIfArrivalsPresent = 9;
  private _maxArrivalRowsToDisplay = (this._maxRowsToDisplay - this._maxDepartureRowsToDisplayIfArrivalsPresent - 1);

  constructor(
    private _mbtaService: MbtaService
  ) { }

  ngOnInit(): void {
    // Set up the header for the display board (day of week, time, etc.)
    const today = new Date();
    this.dayOfWeek = this._weekdays[today.getDay()];
    this.todaysDate = `${today.getMonth() + 1}-${today.getDate()}-${today.getFullYear()}`;
    this.timeNow = this._mbtaService.getMbtaTime(today.toISOString());
    this._getSchedule(); // Generate the schedule board and display it
  }

  /**
   * @method: _getSchedule
   * @description: Generate the departures/arrivals board data for display
   * @returns: Nothing, but the schedule board is available for display
   */
  private async _getSchedule(): Promise<void> {
    // First, get departing trains
    this._scheduleBoardOutbound = await this._getTrainInfo(Direction.Outbound);
    // Prune out the departed trains, then sort the remaining trains by ascending
    // departure time.
    this._scheduleBoardOutbound = this._pruneDeparted(this._scheduleBoardOutbound);
    this._scheduleBoardOutbound = this._sortByTime(this._scheduleBoardOutbound);

    // Now go through a similar process to find any arriving trains.
    this._scheduleBoardInbound = await this._getTrainInfo(Direction.Inbound);
    // The only arrivals we care about are Amtrak, so prune any that are MBTA
    this._scheduleBoardInbound = this._pruneMbta(this._scheduleBoardInbound);
    this._scheduleBoardInbound = this._sortByTime(this._scheduleBoardInbound);

    // Compose the public schedule board for display
    if (this._scheduleBoardInbound.rows.length > 0) {
      this.scheduleBoardToDisplay.rows = [...this._scheduleBoardOutbound.rows.slice(0, this._maxDepartureRowsToDisplayIfArrivalsPresent),
      ...this._scheduleBoardOutbound.rows.slice(0, this._maxArrivalRowsToDisplay)];
    }
    else {
      this.scheduleBoardToDisplay.rows = this._scheduleBoardOutbound.rows.slice(0, this._maxRowsToDisplay);
    }
    this.hasSchedule = true; // Tell Angular it's OK to display the board
  }

  private async _getTrainInfo(direction: Direction): Promise<ScheduleBoard> {
    // First get the predictions.  This has track information, if there is any.
    const predictions: any = await this._mbtaService.getPredictions(direction);
    const _scheduleBoardPredictions: ScheduleBoard = this._mbtaService.translateRawDataToScheduleBoard(predictions, direction);

    // Next, get the schedules.  This has the actual planned departure or arrival times.
    const schedules: any = await this._mbtaService.getSchedules(direction);
    const _scheduleBoardSchedules: ScheduleBoard = this._mbtaService.translateRawDataToScheduleBoard(schedules, direction);

    // Now match the trains in the predictions to the ones in the schedule.  This
    // enables us to update the former with planned departure times.
    _scheduleBoardPredictions.mapToTrain.forEach(
      (row: ScheduleBoardRow, trainNumber: number, map: Map<number, ScheduleBoardRow>): void => {
        // Find the train in the Map of the schedule data to
        // get its scheduled departure or arrival time.
        const scheduledTrain = _scheduleBoardSchedules.mapToTrain.get(trainNumber);
        if (scheduledTrain && scheduledTrain.time) {
          row.time = scheduledTrain.time;
        }
      });
    return _scheduleBoardPredictions; // Filled in with actual train times
  }

  /**
   * Helper function to sort the schedule board rows by departure or arrival time
   */
  private _sortByTime(scheduleBoard: ScheduleBoard): ScheduleBoard {
    if (scheduleBoard.rows.length === 0) {
      return scheduleBoard;
    }
    scheduleBoard.rows.sort((x: ScheduleBoardRow, y: ScheduleBoardRow): number => {
      const today = new Date();
      const todaysDate = `${today.getMonth() + 1}/${today.getDate()}/${today.getFullYear()}`;
      const xTimeStr = `${todaysDate} ${x.time}`;
      const xTime = (new Date(xTimeStr)).getTime();
      const yTimeStr = `${todaysDate} ${y.time}`;
      const yTime = (new Date(yTimeStr)).getTime();
      return xTime - yTime;
    });
    return scheduleBoard;
  }

  /**
   * Helper function to prune all the trains that have departed before now.
   */
  private _pruneDeparted(scheduleBoard: ScheduleBoard): ScheduleBoard {
    const rowsToKeep: ScheduleBoardRow[] = scheduleBoard.rows.filter((row: ScheduleBoardRow) => {
      return (row.status !== 'DEPARTED');
    });
    scheduleBoard.rows = rowsToKeep;
    return scheduleBoard;
  }

  /**
   * Helper function to remove for a ScheduleBoard all MBTA trains
   */
  private _pruneMbta(scheduleBoard: ScheduleBoard): ScheduleBoard {
    const rowsToKeep: ScheduleBoardRow[] = scheduleBoard.rows.filter((row: ScheduleBoardRow) => {
      return (row.carrier !== 'MBTA');
    });
    scheduleBoard.rows = rowsToKeep;
    return scheduleBoard;
  }
}
