import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as fs from 'graceful-fs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  private _mainUrl = 'http://localhost:3000/main';
  private _connectUrl = 'http://localhost:3000/connect/system/clinical/4706?client_id=75c6e99015fe4d5db56a9f5b09aefa16&access_token='
  private _accessToken: string;
  private _scriptContent = ''; // Content to turn into a script file
  public scriptReady = false; // Do we have a script to inject into the page
  public scriptPath = ''; // Filename of the script

  constructor(
    private _httpClient: HttpClient
  ) { }

  async ngOnInit(): Promise<any> {
    const httpOptions = {
      headers: new HttpHeaders({})
    };

    // Create a user and get a token
    const tokenResult = await this._httpClient.get<any>(this._mainUrl, httpOptions).toPromise();
    this._accessToken = tokenResult.accessToken;
    console.log(`Access token: ${this._accessToken}`);

    // Call the Quick Connect to do the OAuth2 login
    this._scriptContent = await this._httpClient.get<string>(`${this._connectUrl}${this._accessToken}`, httpOptions).toPromise();
    this.scriptPath = this._makefile(this._scriptContent); // Turn response into a file
    this.scriptReady = true; // OK to inject the script now
  }

  _makefile(result: any): string {
    const filename = `${Math.floor(10000000 * Math.random())}.html`;
    fs.writeFileSync(filename, result);
    return filename;
  }

}
