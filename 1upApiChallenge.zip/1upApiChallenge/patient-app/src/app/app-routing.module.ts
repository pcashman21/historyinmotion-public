import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { AppComponent } from 'src/app/app.component';
// import { ConnectComponent } from 'src/connect/connect.component';

const routes: Routes = [
  // {
  //   path: 'start',
  //   component: AppComponent
  // },
  // {
  //   path: '/',
  //   component: ConnectComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
