/**
 * This is an uncopyrighted file.
 *
 * @file src/secret.ts
 * @description Client ID and secret for API calls
 *
 * Of course, no one is dumb enough (I hope!) to put stuff like this
 * in a file to begin with, much less name it 'secret.ts'!  In real life,
 * I'd put it in something like the AWS Secrets Manager and use my AWS
 * credentials to access them at application startup.
 */

 export const clientID = '75c6e99015fe4d5db56a9f5b09aefa16';
 export const clientSecret = '1RHq3ZEwZGKeoMFsdP0nOQlCkqyVJUhJ';
 export const EpicSystemID = 4706;