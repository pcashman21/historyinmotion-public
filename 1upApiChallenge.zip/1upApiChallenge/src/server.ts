/**
 * This is an uncopyrighted file.
 *
 * @file server.ts
 * @description Server to handle REST API calls from client
 * and mock reponses to calls that can't be handled locally
 */

// Third-Party Modules
require('dotenv').config();
const express = require('express');
const next = require('next');
const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const path = require('path');
const fs = require('graceful-fs');

// Local Files
const main = require('./main.js');
const auth = require('./auth');
const oneup = require('./oneup');
import { callOneUp } from './user';

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
// Comment out definition of handle -- couldn't
// get calls to handle to work
// const handle = app.getRequestHandler();
const server = express();
const port = 3000;

// Originally I had a stripped-down version of your sample server,
// but was having problems because the NextJS files the server expected
// to find weren't there.  So I tried using the complete sample
// server, with API routes that didn't seem to be called.  That didn't
// help.

app
    .prepare()
    .then(() => {
        server.use(bodyParser.urlencoded({ extended: false }));
        server.use(bodyParser.json());
        server.use(
            cookieSession({
                name: 'demoappsession',
                keys: ['Woof', 'Meow', 'Cluck'], // you should change these
                maxAge: 24 * 60 * 60 * 1000, // 24 hours
            }),
        );

        server.use(auth.passwordless.sessionSupport());
        server.use(
            auth.passwordless.acceptToken({ successRedirect: '/dashboard' }),
        );

        // This request starts the process of creating the user,
        // getting a token, and connecting to a system
        server.get('/main', (req: any, res: any, next: Function) => {
            // Execute the app
            main()
                // main packages the HTML response from
                // the Quick Connect into a file for transmission
                // to the client
                .then((filename: string) => {
                    const options = {
                        root: path.join(__dirname, '..', '..', 'userPages'),
                        dotfiles: 'deny',
                        headers: {
                            'x-timestamp': Date.now(),
                            'x-sent': true
                        }
                    }
                    res.sendFile(filename, options, (err: any) => {
                        if (err) {
                            return next(err);
                        }
                        else {
                            console.log(`Sent file ${filename}`);
                        }
                    });
                })
                .catch((err: any) => {
                    console.log('Oops!');
                    console.log(err);
                    process.exit(1);
                });
        });

        // Not used; part of 1up sample web app
        server.post(
            '/sendtoken',
            auth.passwordless.requestToken((email: any, delivery: any, fn: Function) => fn(null, email)),
            (req: any, res: any) => res.json('ok'),
        );

        // Not used; part of 1up sample web app
        server.get('/callback', auth.authUser, (req: any, res: any) => {
            res.redirect('/dashboard');
        });

        // Not used; part of 1up sample web app
        server.get('/dashboard', auth.authUser, (req: any, res: any) => {
            app.render(req, res, '/dashboard', req.params);
        });

        // When user logs in, this route is called.
        // Mock the response to allow the demo to continue
        server.post('/api/auth', (req: any, res: any) => {
            // Mock the return
            console.log('/api/auth: Mocking the return');
            return res.status(200).json(
                {
                    success:false,
                    errorMessage: {
                        proxies:["Jason Argonaut","Jessica Argonaut"],
                        message:"Please select an account"
                    }
                }
            );
        });

        // Not used; part of 1up sample web app
        // we suggest bundling your requests to the 1uphealth api on the backend
        // and presenting them to the frontend via your own api routes
        server.get('/api/dashboard', auth.authUser, (req: any, res: any) => {
            var oneupAccessToken =
                req.session.oneup_access_token ||
                req.headers.authorization.split(' ')[1];
            oneup.getAllFhirResourceBundles(oneupAccessToken, function (responseData: any) {
                res.send({ token: oneupAccessToken, resources: responseData });
            });
        });

        // More mocking of routes
        server.post('/api/status/:id', (req: any, res: any) => {
            // Mock the return
            console.log(`/api/status/${req.param.id}: Mocking the return`);
            return res.status(200).json(
                {
                    step:"no connect data found"
                }
            );
        });

        // Not used; part of 1up sample web app
        server.get('/logout', (req: any, res: any) => {
            req.session = null;
            res.redirect('/login');
        });

        // Not used; part of 1up sample web app
        server.post('/logout', (req: any, res: any) => {
            req.session = null;
            req.user = null;
            res.json('ok');
        });

        // Not used; part of 1up sample web app
        server.get('/', auth.authUser, (req: any, res: any) => {
            console.log('Get /');
            app.render(req, res, '/index', req.params);
        });

        // For some unknown reason, I couldn't get the NextJS
        // pages to dynamically generate on my localhost.  So
        // to not get stuck, I redirect to the real demo system.
        server.get('*', async (req: any, res: any) => {
            const redirectUrl = `https://quick.1up.health${req.url}`;
            // return handle(req, res); // couldn't get call to work
            const handleResult: any = await callOneUp({
                method: 'GET',
                url: redirectUrl
            });
            // The URL's last piece after the last period is the
            // type of file being sent, so grab it, and use it as extension
            // of a file whose name I generate.
            const extension: string = req.url.split('.').pop();
            const filename = `${(Math.floor(Math.random() * 10000000)).toString()}.${extension}`;
            fs.writeFileSync(path.join(__dirname, '..', '..', 'userPages', filename), handleResult as string, {
                encoding: 'utf8',
                flag: 'w'
            });
            const options = {
                root: path.join(__dirname, '..', '..', 'userPages'),
                dotfiles: 'deny',
                headers: {
                    'x-timestamp': Date.now(),
                    'x-sent': true
                }
            }
            // Send the Javascript or CSS file to the client
            res.sendFile(filename, options, (err: any) => {
                if (err) {
                    return next(err);
                }
                else {
                    console.log(`Sent file ${filename}`);
                }
            });
        });

        server.listen(port, (err: any) => {
            if (err) throw err;
            console.log(`> Ready on http://localhost:${port}`);
        });
    })
    .catch((ex: any) => {
        console.error(ex.stack);
        process.exit(1);
    });

module.exports = server;