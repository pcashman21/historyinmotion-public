/**
 * This is an uncopyrighted file.
 *
 * @file server.ts
 * @description Server to handle REST API calls from client
 */

// Third-Party Modules
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fetchFromOneUp = require('fetch').fetchUrl;
const fs = require('graceful-fs');
const path = require('path');

// Local Files
const main = require('./main.js');

const server = express();
const port = 3000;


server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json());

server.use(function COR(req: any, res: any, next: Function) {
    // ONLY allow preflights from the whitelist of origins
    if (req.headers && req.headers.origin) {
        res.header('Access-Control-Allow-Origin', '*'); //https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin
        // Do allow the client the specify these headers:
        // authorization (needed to pass the user token to a REST endpoint)
        // content-type (to force it to be 'application/json')
        // x-api-attempt (needed in some REST calls to count the number of attempts/retries)
        res.header('Access-Control-Allow-Headers', 'content-type, authorization,accepts,accept,x-api-attempt');
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT');
        // res.header('Access-Control-Max-Age', 0); // @todo num seconds this preflight may be cached client side
        // res.header('Access-Control-Expose-Headers', 'Content-Length, Access-Control-Allow-Origin'); // @todo remove // https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Expose-Headers
        // res.header('Access-Control-Allow-Credentials', true); // https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Credentials
    }
    if (req.method === 'OPTIONS') {
        return res.send();
    }
    else {
        return next();
    }
});

// This request starts the process of creating the user,
// getting a token, and connecting to a system
server.get('/main', (req: any, res: any, next: Function) => {
    // Execute the app
    main()
        .then((result: any) => {
            return res.status(200).json(result)
        })
        .catch((err: any) => {
            console.log('Oops!');
            console.log(err);
            process.exit(1);
        });
});

server.use((req: any, res: any, next: Function) => {
    res.header('Access-Control-Allow-Origin', '*');
    return next();
  });
server.get('/connect/system/clinical/4706', (req: any, res: any, next: Function) => {
    console.log(`==> https://api.1up.health${req.url}`);
    fetchFromOneUp(`https://api.1up.health${req.url}`, {
        method: 'GET'
    }, (err: any, meta: any, body: any) => {
        if (err) {
            return res.status(500).send({
                err
            });
        }
        let result: any;
        try {
            result = JSON.parse(body.toString());
        }
        catch(err) {
            result = body.toString();
        }
        return res.sendFile(path.join(__dirname, '..', '..', 'userPages', _makefile(result)));
    });
});

server.get('/mychart', (req: any, res: any, next: Function) => {
    console.log(`==> https://api.1up.health${req.url}`);
    fetchFromOneUp(`https://api.1up.health${req.url}`, {
        method: 'GET'
    }, (err: any, meta: any, body: any) => {
        if (err) {
            return res.status(500).send({
                err
            });
        }
        let result: any;
        try {
            result = JSON.parse(body.toString());
        }
        catch(err) {
            result = body.toString();
        }
        return res.sendFile(path.join(__dirname, '..', '..', 'userPages', _makefile(result)));
    });
});


// Listen on the designated port
server.listen(port, (err: any) => {
    if (err) throw err;
    console.log(`> Ready on http://localhost:${port}`);
});

function _makefile(result: any): string {
    result = result.replace(/\n|\r|\t/gi,'');
    const filename = `${Math.floor(10000000 * Math.random())}.html`;
    fs.writeFileSync(path.join(__dirname, '..', '..', 'userPages', filename), result);
    return filename;
}

module.exports = server;