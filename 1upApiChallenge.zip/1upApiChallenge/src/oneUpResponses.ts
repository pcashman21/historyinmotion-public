/**
 * This is an uncopyrighted file.
 *
 * @file src/oneUpResponses.ts
 * @description Interface definitions for 1up Health API responses
 */

// Interface object passed back by 1up user management API
// on a call to create a new user
export interface NewUserResponse {
    success: boolean;
    code?: string;
    oneup_user_id?: number;
    app_user_id?: string;
    active?: boolean;
    error?: string;
}

 // Interface object passed back from 1up user management API
 // on a call to get a token from an access code
 export interface TokenResponse {
    success: boolean;
    refresh_token?: string;
    access_token?: string;
    token_type?: string;
    expires_in?: number;
    scope?: string;
    error?: string;
}
