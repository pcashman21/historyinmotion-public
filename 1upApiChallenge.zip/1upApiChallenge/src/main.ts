/**
 * This is an uncopyrighted file.
 *
 * @file main.ts
 * @description Main function to create new user, get tokens, and connect to Epic
 */

// Third-Party Modules
const fs = require('graceful-fs');
const path = require('path');

// Local Files
import { UserCreds } from './user';
import { NewUserResponse, TokenResponse } from './oneUpResponses';
import { EpicSystemID } from './secret';

// Main function to execute
// Returns a Promise that resolves to the string that is
// the name of the file (HTML page) to send to the
// client.
async function main(): Promise<string> {
   // The random localUserID avoids having to worry about trying to get
   // a new user when we already have one (if we used a fixed ID).
   const localUserID = Math.floor(10000000 * Math.random());

   // Create a new user and get a token
   const tokenResponse: TokenResponse = await _getTokens(localUserID);
   if (!tokenResponse || !tokenResponse.access_token) {
      let errorMessage = `Unable to get a token for userID ${localUserID}`;
      errorMessage += tokenResponse ? ` because ${tokenResponse.error}` : `for unknown reason`;
      throw new Error(errorMessage);
   }

   // Use the token to access the Epic system as per the problem definition
   return _connectToSystem({
      accessToken: tokenResponse.access_token,
      systemID: EpicSystemID,
      filename: `page-${localUserID}.html`
   });
}

/**
 * @function _getTokens
 * @description Get an access token for a user ID
 * @param {UserCreds} testUser -- ID (numeric) of user from whom we need a token
 * @returns {Promise<any>} that resolves to a token
 */
async function _getTokens(testUser: number): Promise<TokenResponse> {
   // Create a new user and get its access code
   const newUserResponse: NewUserResponse | undefined = await UserCreds.createNewUser(testUser);
   if (newUserResponse === undefined) {
      throw new Error(`Undefined response from createNewUser call for localUserID ${testUser}`);
   }

   // Now exchange the OAuth2 access code for tokens
   const tokenResponse: TokenResponse | undefined = await UserCreds.exchangeCodeForToken(newUserResponse.code as string);
   return tokenResponse;
}

/**
 * @function _connectToSystem
 * @description Connect to Epic system
 * @param options
 *      {Number} options.systemID -- ID of the Epic system
 *      {String} options.filename -- name of file to which to save the page
 *      {String} options.accessToken -- access token to use
 */
async function _connectToSystem(options: any): Promise<string> {
    const pageToDisplay: string = await UserCreds.connectToSystem(options);
    fs.writeFileSync(path.join(__dirname, '..', '..', 'userPages', options.filename), pageToDisplay, {
        encoding: 'utf8',
        flag: 'w'
    });
    return options.filename;
}

module.exports = main;
