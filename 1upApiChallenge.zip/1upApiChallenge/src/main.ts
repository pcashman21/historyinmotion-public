/**
 * This is an uncopyrighted file.
 *
 * @file main.ts
 * @description Main function to create new user, get tokens, and connect to Epic
 */

// Third-Party Modules

// Local Files
import { UserCreds } from './user';
import { NewUserResponse, TokenResponse } from './oneUpResponses';

// Main function to execute
async function main(): Promise<any> {
   // The random localUserID avoids having to worry about trying to get
   // a new user when we already have one (if we used a fixed ID).
   const localUserID = Math.floor(10000000 * Math.random());

   // Create a new user and get a token
   const tokenResponse: TokenResponse = await _getTokens(localUserID);
   if (!tokenResponse || !tokenResponse.access_token) {
      let errorMessage = `Unable to get a token for userID ${localUserID}`;
      errorMessage += tokenResponse ? ` because ${tokenResponse.error}` : `for unknown reason`;
      throw new Error(errorMessage);
   }

   // Create a patient
   const patientName = `SallySoSick-${Math.floor(1000 * Math.random())}`;
   const patientResponse: any = await _createPatient({
      accessToken: tokenResponse.access_token,
      body: JSON.stringify({
         resourceType: 'Patient',
         id: patientName,
         gender: 'female'
     })
   });

   // Get everything we know about the patient
   const allDataAboutPatient: any = await _getEverything({
      accessToken: tokenResponse.access_token,
      patientID: patientResponse.id
   });

   return {
      patientName,
      patientID: patientResponse.id,
      totalRecordsFound: allDataAboutPatient.total,
      recordsFound: allDataAboutPatient.entry
   };

}

/**
 * @function _getTokens
 * @description Get an access token for a user ID
 * @param {UserCreds} testUser -- ID (numeric) of user from whom we need a token
 * @returns {Promise<any>} that resolves to a token
 */
async function _getTokens(testUser: number): Promise<TokenResponse> {
   // Create a new user and get its access code
   const newUserResponse: NewUserResponse | undefined = await UserCreds.createNewUser(testUser);
   if (newUserResponse === undefined) {
      throw new Error(`Undefined response from createNewUser call for localUserID ${testUser}`);
   }

   // Now exchange the OAuth2 access code for tokens
   const tokenResponse: TokenResponse | undefined = await UserCreds.exchangeCodeForToken(newUserResponse.code as string);
   return tokenResponse;
}

/**
 * Create a Patient resource
 */
async function _createPatient(options: any): Promise<any> {
    const patientResponse: any = await UserCreds.createPatient(options);
    return patientResponse;
}

/**
 * Get everything about a patient
 */
async function _getEverything(options: any): Promise<any> {
   const eveythingResponse = await UserCreds.getEverythingAboutPatient(options);
   return eveythingResponse;
}

module.exports = main;
