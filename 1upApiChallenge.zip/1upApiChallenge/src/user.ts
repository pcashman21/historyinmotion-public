/**
 * This is an uncopyrighted file.
 *
 * @file src/user.ts
 * @description Interface to 1up.health API for getting user data
 */

// Third-Party Modules
const fetch = require('fetch').fetchUrl;

// Local Files
import * as Secret from './secret';
import { NewUserResponse, TokenResponse }  from './oneUpResponses';

/**
 * @class UserCreds
 * @description Create a user and get its credentials
 */
export class UserCreds {

    constructor() {}

    /**
     * @function createNewUser
     * @description Call 1up's user creation REST API and return result
     * @param {Number} appUserID -- ID of user to create
     * @return {Promise<NewUserResponse>} resolves to 1up's response object
     */
    static async createNewUser(appUserID: number): Promise<NewUserResponse> {
        return callOneUp({
            method: 'POST',
            url: `https://api.1up.health/user-management/v1/user?app_user_id=${appUserID}&client_id=${Secret.clientID}&client_secret=${Secret.clientSecret}`
        }) as Promise<NewUserResponse>;
    }

    /**
     * @function exchangeCodeForToken
     * @description Exchange an access code for a bearer and refresh token
     * @param {String} accessCode -- valid access code
     * @returns {Promise<TokenResponse>} resolves to TokenResponse
     */
    static async exchangeCodeForToken(accessCode: string): Promise<TokenResponse> {
        return callOneUp({
            method: 'POST',
            url: `https://api.1up.health/fhir/oauth2/token?code=${accessCode}&client_id=${Secret.clientID}&client_secret=${Secret.clientSecret}&grant_type=authorization_code`
        }) as Promise<TokenResponse>;
    }

    /**
     * @description Create a patient
     */
    static async createPatient(options: any): Promise<any> {
        return callOneUp({
            method: 'POST',
            url: `https://api.1up.health/fhir/dstu2/Patient?access_token=${options.accessToken}`,
            body: options.body
        }) as Promise<any>;
    }

    /**
     * Get everything we know about the patient
     */
    static async getEverythingAboutPatient(options: any): Promise<any> {
        return callOneUp({
            method: 'GET',
            url: `https://api.1up.health/fhir/dstu2/Patient/${options.patientID}/$everything?access_token=${options.accessToken}`
        });
    }
}

/**
 * @function callOneUp
 * @description Utility function to call a 1up REST API and return the result
 * @param {Any} options
 *      options.method:     HTTP method
 *      options.url         URL of REST API
 * @returns {Promise<any>} resolves to JSON-parsed result of REST API call
 *  NOTE: Caller must assert the type of the result.
 */
export function callOneUp(options: any): Promise<any> {
    return new Promise((resolve, reject) => {
        const url = options.url;
        const method = options.method;
        console.log(`Calling ${method} ${url}`);
        const fetchOptions: any = {
            method: options.method
        };
        if (options.body) {
            fetchOptions.payload = options.body
            console.log(`POSTing body ${fetchOptions.payload}`);
        }
        fetch(url, fetchOptions, (err: any, meta: any, body: any) => {
            if (err) {
                console.log(`Error meta object from ${options.method} ${url}`);
                console.log(meta);
                return reject(err);
            }
            let result: any;
            try {
                result = JSON.parse(body.toString());
            }
            catch(err) {
                result = body.toString();
            }
            return resolve(result);
        });
    });
}
