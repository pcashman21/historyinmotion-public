This is Paul Cashman's SECOND partial solution to the `1up Health API Challenge`.
Important keys:
* Application Name: `ApiChallengeForPaul`
* OAuth2 Redirect URL: `http://localhost:3000` (probably should have been `/callback`, but that is not what the directions advised)
* OAuth2 Client Id: `75c6e99015fe4d5db56a9f5b09aefa16`
* OAuth2 Client Secret: `1RHq3ZEwZGKeoMFsdP0nOQlCkqyVJUhJ`

The app creates a new user, exchanges the user's code for an access and renewal token, creates a patient with an ID of SallySoSick-xxx, and retrieves that patient via a call to $everything.  It does NOT use the QuickConnect API to perform an
OAuth2 login to the Epic system.  I tried to build an Angular app to do this, and the code for it is in the 1upApiChallenge/patient-app folder, but I could not get it
to work.

`HOW TO BUILD AND RUN THE APP`
* If you haven't installed TypeScript, do this:
  * `$ npm install -g typescript@latest`
* Unzip the zip file to create the folder `1upApiChallenge`.  All the following steps occur within that folder.
* `$ npm i` to create the `node_modules` folder.
* `$ npm run api` does the following:
  * Deletes the `build` folder and subfolders.
  * Creates the `build` and `build/src` folders.
  * Transpiles the TypeScript files (Note: the command line stuff to do this is
  admittedly a kludge.  I had it working through the `tsconfig.json` file, but
  that stopped working for some unknown reason last night, and I didn't feel that
  it was that important to fix.)
  * Runs the built version of the app (`./build/index-challenge.js`).
* The app gives the message `Ready on http://localhost:3000`.  At that point,
point your browser to `http://localhost:3000/main` to get the app going.  It will print out the calls it makes on the console.  SallySoSick's record shows up on the page as a JSON string, which is roughly human-readable.  I could have modified the Angular app to prettyprint it, but I'd spent enough time on this problem already.

`DESIGN DECISIONS AND PROBLEMS ENCOUNTERED ALONG THE WAY`
* I decided to write this in TypeScript.  It's a little more effort, but pays off in more reliable code and faster detection of errors.
* I took Marvin's guidance ("You're trying to do too much") to heart, and so opted to do the "create a patient and retrieve the patient information" path.  In the course of creating an Angular app to display the results of the $everything call, I thought I saw a way to solve the QuickConnect problem, but that led me down a trail of complications (e.g., solving the CORS problem of calling a server at port 3000 from the Angular app running on port 4200, trying to inject a script from a REST API call into the Angular page, mocking the calls to MyChart, etc.) which seemed contrary to Marvin's guidance.

`NEXT STEPS`
* From a coding perspective, there is little or no error checking (bad!).  There is a really neat pattern we have for error-checking around `await <function>` calls, but I didn't take the time to put it in.
