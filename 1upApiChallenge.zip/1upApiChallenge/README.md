This is Paul Cashman's partial solution to the `1up Health API Challenge`.
Important keys:
* Application Name: `ApiChallengeForPaul`
* OAuth2 Redirect URL: `http://localhost:3000` (probably should have been `/callback`, but I doubt if that would have gotten me over the hump)
* OAuth2 Client Id: `75c6e99015fe4d5db56a9f5b09aefa16`
* OAuth2 Client Secret: `1RHq3ZEwZGKeoMFsdP0nOQlCkqyVJUhJ`

The app does not run to completion.  It will get to the Epic login page and the
following page for choosing between Jason and Jessica Argonaut.  To run it, do the following:

`HOW TO BUILD AND RUN THE APP`
* If you haven't installed TypeScript, do this:
  * `$ npm install -g typescript@latest`
* Unzip the zip file to create the folder `1upApiChallenge`.  All the following steps occur within that folder.
* `$ npm i` to create the `node_modules` folder.
* `$ npm run api` does the following:
  * Deletes the `build` folder and subfolders.
  * Creates the `build` and `build/src` folders.
  * Transpiles the TypeScript files (Note: the command line stuff to do this is
  admittedly a kludge.  I had it working through the `tsconfig.json` file, but
  that stopped working for some unknown reason last night, and I didn't feel that
  it was that important to fix.)
  * Copies the JavaScript and JSON files that I copied from your GitHub repo into the `build/src` folder.
  * Runs the built version of the app (`./build/index-challenge.js`).
* The app gives the message `Ready on http://localhost:3000`.  At that point,
aim your browser to `http://localhost:3000/main` to get the app going.  It will print out the calls it makes on the console.

`DESIGN DECISIONS AND PROBLEMS ENCOUNTERED ALONG THE WAY`
* I decided to write this in TypeScript.  It's a little more effort, but pays off in more reliable code and faster detection of errors.
* Getting the calls working to create a user and get tokens was easy.  The documentation for the QuickConnect seemed to me to be sadly lacking.  By making the call from the browser, I was able to see what calls were being made and what was being returned.  Clearly, I needed to make those calls to get the JavaScript and CSS to make the page look and behave right.  Rather than try to dive into NextJS, which I don't know at all, I decided to mock the local calls by calling
the 1up endpoints (admittedly, mocking is usually done the other way around).  I called the endpoint, got the result, turned it into a file, and sent the file to the browser.  That worked.
* I was able to mock the `/api/auth` just by observing what the real system returned and returning that without making any REST API call.
* I was trying to mock the `api/status/:id` call as well, but for some reason that route is not being hit, even though it's been placed before the `*` route.  I haven't debugged that, and it ends up causing an unhandled promise rejection.
* I originally started out with a barebones server of my own, but when I realized I needed to refer the NextJS calls back to your endpoints, I copied your sample server and some of the files from your GitHib repo.  Much of the code is not needed (and is so noted).  It took a while to get your sample app to work, because the versions of many of the packages were out of sync.  I took a gamble which I would not normally do in the normal course of development, namely, I installed the latest version of all the necessary packages from your `package.json`, despite the fact that in some cases your specified package was two, three, or more major versions behind.  But the gamble paid off and the server finally worked.

`OTHER OPERATIONAL INFO`
* The `.next`, `pages`, and `public` folders are supposedly used by NextJS.
* The `userPages` folder is where I store the temp files created when I get JavaScript, CSS, etc. from your endpoints.  The files have randomly generated names.

`NEXT STEPS`
* If I had the time, I supect (although I can't find it in your documentation) that the `/api/auth` call will eventually return a patient ID, which could then be used for the `$everything` call.  Once I had that, getting tand display the data would be easy.
* From a coding perspective, there is little or no error checking (bad!).  There is a really neat pattern we have for error-checking around `await <function>` calls, but I didn't take the time to put it in.
