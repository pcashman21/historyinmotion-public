/**
 * This is an uncopyrighted file.
 *
 * @file index-challenge.ts
 * @description Paul Cashman's solution to 1up Health's API Challenge
 */

// Third-Party Modules
const sls = require('serverless-http');
const serverApp = require('./src/server.js');
const binaryMimeTypes = require('./src/binaryMimeTypes.js');

// Start the server that will handle the callback when we connect to the Epic system
export const server = sls(serverApp, {
   binary: binaryMimeTypes,
});
